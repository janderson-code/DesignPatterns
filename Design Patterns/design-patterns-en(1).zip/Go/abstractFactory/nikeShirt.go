package main

type nikeShirt struct {
	shirt
}
