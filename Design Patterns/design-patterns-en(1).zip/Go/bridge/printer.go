package main

type printer interface {
	printFile()
}
