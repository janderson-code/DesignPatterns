package main

type departmentBase struct {
	nextDepartment department
}
